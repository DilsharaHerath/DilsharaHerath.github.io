---
title: "Your Paper Title"
collection: publications
permalink: /publication/2025-your-paper-slug
date: 2025-06-08
pubtype: conference   # 'conference' or 'journal'
venue_name: "International Conference on Advancements in Computing 2024 (ICAC 2024)"
venue_url: "https://example.com"
status: "Accepted & to be publication"   # optional
impact_factor: ""                         # journals only, optional
authors_html: >
  <a href="https://example.com/you">Your Name</a>, Coauthor 1, Coauthor 2
paperurl: "https://example.com/paper.pdf"
slidesurl: ""
codeurl: ""
bibtexurl: ""
award: "Outstanding Paper Award"          # optional
contribution: "Conceptualization, Methodology, Formal analysis, Software, Writing – Original Draft."
doi_url: "https://doi.org/10.1109/ICAC64487.2024.10851169"
doi_display: "10.1109/ICAC64487.2024.10851169"
---

<!-- Optional abstract/notes -->
